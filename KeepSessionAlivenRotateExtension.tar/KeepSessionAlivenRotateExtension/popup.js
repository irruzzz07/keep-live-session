document.getElementById("startButton").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "start" });
    chrome.storage.local.set({ isActive: true });
    document.getElementById("status").innerText = "Status: Active";
});

document.getElementById("stopButton").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "stop" });
    chrome.storage.local.set({ isActive: false });
    document.getElementById("status").innerText = "Status: Inactive";
});

// Inisialisasi status
chrome.storage.local.get("isActive", (result) => {
    document.getElementById("status").innerText = result.isActive ? "Status: Active" : "Status: Inactive";
});
