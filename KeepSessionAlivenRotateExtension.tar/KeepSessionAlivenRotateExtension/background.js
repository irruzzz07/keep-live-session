// background.js

let keepAliveInterval;
let activitySimulationInterval;
let activeTabIds = [];

// Fungsi Ping Server
function pingServer() {
    fetch("https://app.aphone.com/keep-session-alive")
        .then(() => console.log("Session kept alive"))
        .catch((error) => console.error("Error keeping session alive:", error));
}

// Fungsi untuk simulasi aktivitas pada tab
function simulateTabActivity(tabId) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
            window.scrollBy(0, 1); // Scroll down by 1 pixel
            window.scrollBy(0, -1); // Scroll back up
        },
    });
}

// Memulai interval untuk menjaga sesi tetap hidup
function startKeepAlive() {
    if (keepAliveInterval) clearInterval(keepAliveInterval);
    keepAliveInterval = setInterval(pingServer, 60 * 1000); // Ping tiap 1 menit
}

// Memulai simulasi aktivitas pada setiap tab yang aktif
function startActivitySimulation() {
    if (activitySimulationInterval) clearInterval(activitySimulationInterval);
    activitySimulationInterval = setInterval(() => {
        activeTabIds.forEach((tabId) => simulateTabActivity(tabId));
    }, 30 * 1000); // Simulasi aktivitas tiap 30 detik
}

// Menangani perubahan fokus jendela
chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
        // Jendela Edge diminimalkan, hentikan simulasi aktivitas
        clearInterval(activitySimulationInterval);
    } else {
        // Jendela aktif kembali, mulai simulasi aktivitas
        chrome.tabs.query({ url: "*://app.aphone.com/*" }, (tabs) => {
            activeTabIds = tabs.map((tab) => tab.id); // Menyimpan ID tab aktif
            startActivitySimulation();
        });
    }
});

// Menangani pesan dari popup.js
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "start") {
        startKeepAlive();
        chrome.tabs.query({ url: "*://app.aphone.com/*" }, (tabs) => {
            activeTabIds = tabs.map((tab) => tab.id); // Simpan ID semua tab
            startActivitySimulation();
        });
    } else if (message.action === "stop") {
        clearInterval(keepAliveInterval);
        clearInterval(activitySimulationInterval);
    }
});

// Memulai sesi "keep-alive" saat ekstensi diaktifkan
chrome.storage.local.get(["isActive"], (result) => {
    if (result.isActive) {
        startKeepAlive();
        chrome.tabs.query({ url: "*://app.aphone.com/*" }, (tabs) => {
            activeTabIds = tabs.map((tab) => tab.id);
            startActivitySimulation();
        });
    }
});
