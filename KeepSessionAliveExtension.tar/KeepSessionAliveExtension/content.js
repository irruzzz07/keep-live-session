// Simulasi interaksi ringan setiap 1 menit untuk menjaga tab aktif
setInterval(() => {
    const tempElement = document.getElementById('session-keep-alive-temp');
    
    if (!tempElement) {
        const elem = document.createElement('div');
        elem.style.display = 'none';
        elem.id = 'session-keep-alive-temp';
        document.body.appendChild(elem);
    } else {
        tempElement.innerText = new Date().toISOString();
    }

    console.log("Interaksi ringan dilakukan untuk menjaga sesi tetap aktif");
}, 60 * 1000); // 1 menit
