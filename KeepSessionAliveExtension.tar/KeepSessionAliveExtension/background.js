// background.js

let keepAliveInterval;

// Mulai sesi "keep-alive" dan tambahkan alarm
function startKeepAlive() {
    if (keepAliveInterval) clearInterval(keepAliveInterval);

    // Menggunakan Alarm API untuk ping setiap 1 menit (300.000 ms)
    chrome.alarms.create("keepAliveAlarm", { periodInMinutes: 1 });

    // Ping juga secara manual setiap interval sebagai cadangan
    keepAliveInterval = setInterval(() => {
        pingServer();
    }, 1 * 60 * 1000); // 1 menit
}

// Fungsi untuk menghentikan alarm dan interval
function stopKeepAlive() {
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
        keepAliveInterval = null;
    }
    chrome.alarms.clear("keepAliveAlarm");
}

// Fungsi Ping ke Server
function pingServer() {
    fetch("https://app.aphone.com/keep-session-alive")
        .then(() => console.log("Session kept alive"))
        .catch((error) => console.error("Error keeping session alive:", error));
}

// Listener untuk menangani alarm
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "keepAliveAlarm") {
        pingServer();
    }
});

// Event untuk menangani pesan dari popup.js
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "start") {
        startKeepAlive();
    } else if (message.action === "stop") {
        stopKeepAlive();
    }
});

// Inisialisasi awal saat ekstensi dijalankan
chrome.storage.local.get(["isActive"], (result) => {
    if (result.isActive) {
        startKeepAlive();
    }
});
