// Mendapatkan elemen dari popup.html
const statusText = document.getElementById("status");
const toggleButton = document.getElementById("toggleButton");

// Memeriksa status dari chrome.storage saat popup terbuka
chrome.storage.local.get(["isActive"], (result) => {
    const isActive = result.isActive || false;
    statusText.textContent = isActive ? "Active" : "Inactive";
    toggleButton.textContent = isActive ? "Stop Keeping Alive" : "Start Keeping Alive";
});

// Menangani klik pada tombol untuk mengaktifkan/mematikan sesi "keep-alive"
toggleButton.addEventListener("click", () => {
    // Toggle status dan simpan di chrome.storage
    const isActive = statusText.textContent === "Inactive";
    chrome.storage.local.set({ isActive: isActive }, () => {
        // Perbarui status dan teks tombol di popup
        statusText.textContent = isActive ? "Active" : "Inactive";
        toggleButton.textContent = isActive ? "Stop Keeping Alive" : "Start Keeping Alive";

        // Kirim pesan ke background.js untuk mulai atau berhenti keep-alive
        chrome.runtime.sendMessage({ action: isActive ? "start" : "stop" });
    });
});
